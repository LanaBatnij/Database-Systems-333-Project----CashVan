public class Branch {
    private int branchID;
    private String address;
    private int productID;

    public Branch(int branchID, String address, int productID) {
        this.branchID = branchID;
        this.address = address;
        this.productID = productID;
    }

    public int getBranchID() {
        return branchID;
    }

    public void setBranchID(int branchID) {
        this.branchID = branchID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }
}