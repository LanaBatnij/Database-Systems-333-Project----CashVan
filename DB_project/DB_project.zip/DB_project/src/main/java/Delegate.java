public class Delegate {
    private int SNN;
    private int vanID;

    public Delegate(int SNN, int vanID) {
        this.SNN = SNN;
        this.vanID = vanID;
    }

    public int getSNN() {
        return SNN;
    }

    public void setSNN(int SNN) {
        this.SNN = SNN;
    }

    public int getVanID() {
        return vanID;
    }

    public void setVanID(int vanID) {
        this.vanID = vanID;
    }
}