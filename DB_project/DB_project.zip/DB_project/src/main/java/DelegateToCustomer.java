import java.util.*;
public class DelegateToCustomer {
    private int SNN;
    private int custID;
    private Date dateOfStart;
    private int paymentID;


    public DelegateToCustomer(int SNN, int custID, Date dateOfStart, int paymentID) {
        this.SNN = SNN;
        this.custID = custID;
        this.dateOfStart = dateOfStart;
        this.paymentID = paymentID;
    }

    public int getSNN() {
        return SNN;
    }

    public void setSNN(int SNN) {
        this.SNN = SNN;
    }

    public int getCustID() {
        return custID;
    }

    public void setCustID(int custID) {
        this.custID = custID;
    }

    public Date getDateOfStart() {
        return dateOfStart;
    }

    public void setDateOfStart(Date dateOfStart) {
        this.dateOfStart = dateOfStart;
    }

    public int getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(int paymentID) {
        this.paymentID = paymentID;
    }
}