import java.util.*;

public class Employee {
    private int SNN;
    private String name;
    private String address;
    private String phoneNumber;
    private boolean availability;
    private double salary;
    private String gmail;
    private Date dateOfBirth;
    private String civilStatus;
    private String access;

    public Employee(int SNN, String name, String address, String phoneNumber, boolean availability,
                    double salary, String gmail, Date dateOfBirth, String civilStatus, String access) {
        this.SNN = SNN;
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.availability = availability;
        this.salary = salary;
        this.gmail = gmail;
        this.dateOfBirth = dateOfBirth;
        this.civilStatus = civilStatus;
        this.access = access;
    }

    public int getSNN() {
        return SNN;
    }

    public void setSNN(int SNN) {
        this.SNN = SNN;
    }

    public String getEName() {
        return name;
    }

    public void setEName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public boolean isAvailability() {
        return availability;
    }

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getGmail() {
        return gmail;
    }

    public void setGmail(String gmail) {
        this.gmail = gmail;
    }

    public Date getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public String getCivilStatus() {
        return civilStatus;
    }

    public void setCivilStatus(String civilStatus) {
        this.civilStatus = civilStatus;
    }

    public String getAccess() {
        return access;
    }

    public void setAccess(String access) {
        this.access = access;
    }
}
