public class Manager {
    private int SNN;

    public Manager(int SNN) {
        this.SNN = SNN;
    }

    public int getSNN() {
        return SNN;
    }

    public void setSNN(int SNN) {
        this.SNN = SNN;
    }
}