public class PaymentToProduct {
    private int productID;
    private int paymentID;
    private int quantity;
    private double productPrice;


    public PaymentToProduct(int productID, int paymentID, int quantity, double productPrice) {
        this.productID = productID;
        this.paymentID = paymentID;
        this.quantity = quantity;
        this.productPrice = productPrice;
    }


    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getPaymentID() {
        return paymentID;
    }

    public void setPaymentID(int paymentID) {
        this.paymentID = paymentID;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }
}