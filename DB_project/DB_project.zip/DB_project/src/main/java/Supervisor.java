public class Supervisor {
    private int SNN;

    public Supervisor(int SNN) {
        this.SNN = SNN;
    }

    public int getSNN() {
        return SNN;
    }

    public void setSNN(int SNN) {
        this.SNN = SNN;
    }
}
