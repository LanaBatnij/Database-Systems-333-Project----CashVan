public class Van {
    private int vanID;
    private double price;
    private int quantity;
    private int productID;
    private String productName;
    private double unit;
    private String barcode;

    public Van(int vanID, double price, int quantity, int productID, String productName, double unit, String barcode) {
        this.vanID = vanID;
        this.price = price;
        this.quantity = quantity;
        this.productID = productID;
        this.productName = productName;
        this.unit = unit;
        this.barcode = barcode;
    }

    public int getVanID() {
        return vanID;
    }

    public void setVanID(int vanID) {
        this.vanID = vanID;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getUnit() {
        return unit;
    }

    public void setUnit(double unit) {
        this.unit = unit;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }
}