public class VanToDelegate {
    private int SNN;
    private int vanID;
    private String drivingLicense;
    private String insurance;


    public VanToDelegate(int SNN, int vanID, String drivingLicense, String insurance) {
        this.SNN = SNN;
        this.vanID = vanID;
        this.drivingLicense = drivingLicense;
        this.insurance = insurance;
    }

    public int getSNN() {
        return SNN;
    }

    public void setSNN(int SNN) {
        this.SNN = SNN;
    }

    public int getVanID() {
        return vanID;
    }

    public void setVanID(int vanID) {
        this.vanID = vanID;
    }

    public String getDrivingLicense() {
        return drivingLicense;
    }

    public void setDrivingLicense(String drivingLicense) {
        this.drivingLicense = drivingLicense;
    }

    public String getInsurance() {
        return insurance;
    }

    public void setInsurance(String insurance) {
        this.insurance = insurance;
    }
}