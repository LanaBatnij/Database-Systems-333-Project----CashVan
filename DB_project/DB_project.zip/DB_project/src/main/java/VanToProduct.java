import java.util.*;
public class VanToProduct {
    private int productID;
    private int vanID;
    private Date dateOfImport;
    private Date dateOfExpired;


    public VanToProduct(int productID, int vanID, Date dateOfImport, Date dateOfExpired) {
        this.productID = productID;
        this.vanID = vanID;
        this.dateOfImport = dateOfImport;
        this.dateOfExpired = dateOfExpired;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getVanID() {
        return vanID;
    }

    public void setVanID(int vanID) {
        this.vanID = vanID;
    }

    public Date getDateOfImport() {
        return dateOfImport;
    }

    public void setDateOfImport(Date dateOfImport) {
        this.dateOfImport = dateOfImport;
    }

    public Date getDateOfExpired() {
        return dateOfExpired;
    }

    public void setDateOfExpired(Date dateOfExpired) {
        this.dateOfExpired = dateOfExpired;
    }
}